# SimBuss OSM Route Downloader

Protótipo em Python + wxPython que pesquisa relações de transporte público no OpenStreetMap via Overpass API e gera GeoJSON para o `OsmReader` do SimBussEditor.

## Instalar

```powershell
py -m pip install -r requirements.txt
```

## Executar

```powershell
py main.py
```

## Uso

1. Digite a referência ou parte do nome da linha.
2. Pressione Enter ou Pesquisar.
3. Navegue pelos resultados com as setas.
4. Pressione Enter no resultado desejado.
5. Escolha onde salvar o `.geojson`.

Atalhos: Ctrl+L volta à pesquisa; F5 repete a pesquisa; Enter na lista baixa a linha selecionada.

O arquivo contém a relação principal como espinha (`relation/...`), ruas `highway=*` próximas à rota e nós relevantes. Membros da relação recebem `@relations` com seus papéis, inclusive `stop` e `platform`.
