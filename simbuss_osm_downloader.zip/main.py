import json
import re
import threading
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

import wx

APP_TITLE = "SimBuss OSM Route Downloader"
OVERPASS_URL = "https://overpass-api.de/api/interpreter"
USER_AGENT = "SimBuss-OSM-Route-Downloader/0.1"

HIGHWAY_NODE_VALUES = (
    "traffic_signals", "speed_camera", "stop", "bus_stop",
    "toll_booth", "mini_roundabout",
)
AMENITY_NODE_VALUES = ("bus_station", "fuel", "depot")
TRAFFIC_CALMING_VALUES = ("bump", "hump")
JUNCTION_VALUES = ("roundabout", "circular")


def overpass_escape(value: str) -> str:
    return (
        value.replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\n", " ")
        .replace("\r", " ")
    )


def request_overpass(query: str, timeout: int = 90) -> dict:
    data = urllib.parse.urlencode({"data": query}).encode("utf-8")
    req = urllib.request.Request(
        OVERPASS_URL,
        data=data,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            raw = response.read()
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        detail = re.sub(r"<[^>]+>", " ", body)
        detail = re.sub(r"\s+", " ", detail).strip()
        if len(detail) > 300:
            detail = detail[:300] + "..."
        raise RuntimeError(f"Overpass respondeu HTTP {exc.code}. {detail}".strip()) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Não foi possível acessar o Overpass: {exc.reason}") from exc

    try:
        return json.loads(raw.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise RuntimeError("O Overpass retornou uma resposta que não é JSON válido.") from exc


def search_routes(term: str) -> list[dict]:
    escaped = overpass_escape(term)
    query = f"""
[out:json][timeout:30];
(
  relation
    [\"type\"=\"route\"]
    [\"route\"~\"^(bus|trolleybus|light_rail)$\"]
    [\"ref\"~\"{escaped}\",i];
  relation
    [\"type\"=\"route\"]
    [\"route\"~\"^(bus|trolleybus|light_rail)$\"]
    [\"name\"~\"{escaped}\",i];
);
out tags 60;
"""

    data = request_overpass(query, timeout=45)
    results = []
    seen = set()

    for element in data.get("elements", []):
        if element.get("type") != "relation":
            continue
        relation_id = element.get("id")
        if relation_id in seen:
            continue
        seen.add(relation_id)
        tags = element.get("tags", {})
        results.append({
            "id": relation_id,
            "ref": tags.get("ref", ""),
            "name": tags.get("name", ""),
            "from": tags.get("from", ""),
            "to": tags.get("to", ""),
            "operator": tags.get("operator", ""),
            "network": tags.get("network", ""),
            "route": tags.get("route", ""),
            "tags": tags,
        })

    lowered = term.casefold()

    def score(item):
        ref = item["ref"].casefold()
        name = item["name"].casefold()
        if ref == lowered:
            return (0, ref, name)
        if name == lowered:
            return (1, ref, name)
        if ref.startswith(lowered):
            return (2, ref, name)
        if lowered in ref:
            return (3, ref, name)
        if name.startswith(lowered):
            return (4, ref, name)
        return (5, ref, name)

    results.sort(key=score)
    return results


def download_route_context(relation_id: int) -> dict:
    highway_regex = "|".join(HIGHWAY_NODE_VALUES)
    amenity_regex = "|".join(AMENITY_NODE_VALUES)
    calming_regex = "|".join(TRAFFIC_CALMING_VALUES)
    junction_regex = "|".join(JUNCTION_VALUES)

    query = f"""
[out:json][timeout:90][maxsize:536870912];
relation({int(relation_id)})->.route;
way(r.route)->.routeways;
node(r.route)->.routenodes;
way(around.routeways:25)[\"highway\"]->.roads;
(
  node(around.routeways:25)[\"highway\"~\"^({highway_regex})$\"];
  node(around.routeways:25)[\"amenity\"~\"^({amenity_regex})$\"];
  node(around.routeways:25)[\"traffic_calming\"~\"^({calming_regex})$\"];
  node(around.routeways:25)[\"junction\"~\"^({junction_regex})$\"];
  node(around.routeways:25)[\"landuse\"=\"depot\"];
)->.near_nodes;
(
  .route;
  .routeways;
  .roads;
  .routenodes;
  .near_nodes;
);
out body geom;
"""
    return request_overpass(query, timeout=120)


def tags_to_properties(element: dict) -> dict:
    props = {"@id": f'{element.get("type")}/{element.get("id")}' }
    props.update(element.get("tags") or {})
    return props


def coords_from_geometry(geometry) -> list[list[float]]:
    if not geometry:
        return []
    coords = []
    for point in geometry:
        if "lon" in point and "lat" in point:
            coords.append([point["lon"], point["lat"]])
    return coords


def build_geojson(overpass_data: dict, relation_id: int) -> dict:
    elements = overpass_data.get("elements", [])
    relation = None
    ways_by_id = {}
    nodes_by_id = {}

    for element in elements:
        element_type = element.get("type")
        element_id = element.get("id")
        if element_type == "relation" and element_id == relation_id:
            relation = element
        elif element_type == "way":
            ways_by_id[element_id] = element
        elif element_type == "node":
            nodes_by_id[element_id] = element

    if relation is None:
        raise RuntimeError("A relação selecionada não veio na resposta do Overpass.")

    features = []
    spine_lines = []
    node_roles: dict[int, list[str]] = {}

    for member in relation.get("members", []):
        member_type = member.get("type")
        member_ref = member.get("ref")
        role = member.get("role", "")

        if member_type == "way":
            coords = coords_from_geometry(member.get("geometry"))
            if len(coords) < 2:
                way = ways_by_id.get(member_ref)
                if way:
                    coords = coords_from_geometry(way.get("geometry"))
            if len(coords) >= 2:
                spine_lines.append(coords)
        elif member_type == "node":
            node_roles.setdefault(member_ref, []).append(role)

    if not spine_lines:
        raise RuntimeError(
            "Não consegui obter geometria dos ways membros da relação. "
            "A relação pode estar incompleta no OpenStreetMap."
        )

    relation_props = tags_to_properties(relation)
    if len(spine_lines) == 1:
        spine_geometry = {"type": "LineString", "coordinates": spine_lines[0]}
    else:
        spine_geometry = {"type": "MultiLineString", "coordinates": spine_lines}

    features.append({
        "type": "Feature",
        "properties": relation_props,
        "geometry": spine_geometry,
    })

    for way in ways_by_id.values():
        tags = way.get("tags") or {}
        if "highway" not in tags:
            continue
        coords = coords_from_geometry(way.get("geometry"))
        if len(coords) < 2:
            continue
        features.append({
            "type": "Feature",
            "properties": tags_to_properties(way),
            "geometry": {"type": "LineString", "coordinates": coords},
        })

    for node_id, node in nodes_by_id.items():
        lat = node.get("lat")
        lon = node.get("lon")
        if lat is None or lon is None:
            continue

        props = tags_to_properties(node)
        roles = [r for r in node_roles.get(node_id, []) if r]
        if roles:
            props["@relations"] = [
                {
                    "rel": relation_id,
                    "role": role,
                    "reltags": relation.get("tags") or {},
                }
                for role in roles
            ]

        features.append({
            "type": "Feature",
            "properties": props,
            "geometry": {"type": "Point", "coordinates": [lon, lat]},
        })

    return {
        "type": "FeatureCollection",
        "generator": APP_TITLE,
        "osm_relation_id": relation_id,
        "features": features,
    }


def safe_filename(route: dict) -> str:
    base = route.get("ref") or route.get("name") or f"relation_{route['id']}"
    base = re.sub(r'[<>:"/\\|?*\x00-\x1F]', "_", base)
    base = re.sub(r"\s+", " ", base).strip(" .")
    return (base or f"relation_{route['id']}") + ".geojson"


def route_accessible_text(route: dict) -> str:
    pieces = []
    if route.get("ref"):
        pieces.append(f"Referência {route['ref']}")
    if route.get("name"):
        pieces.append(route["name"])
    if route.get("from") or route.get("to"):
        pieces.append(
            f"de {route.get('from') or 'origem não informada'} "
            f"para {route.get('to') or 'destino não informado'}"
        )
    if route.get("operator"):
        pieces.append(f"operador {route['operator']}")
    if route.get("network"):
        pieces.append(f"rede {route['network']}")
    pieces.append(f"relação OSM {route['id']}")
    return "; ".join(pieces)


class MainFrame(wx.Frame):
    def __init__(self):
        super().__init__(None, title=APP_TITLE, size=(900, 620))
        self.routes = []
        self.busy = False

        panel = wx.Panel(self)
        main = wx.BoxSizer(wx.VERTICAL)

        intro = wx.StaticText(
            panel,
            label=(
                "Pesquise uma linha pelo número, referência ou nome. "
                "Use as setas na lista e pressione Enter para salvar o GeoJSON."
            ),
        )
        intro.Wrap(820)
        main.Add(intro, 0, wx.ALL | wx.EXPAND, 10)

        search_label = wx.StaticText(panel, label="Linha de ônibus:")
        main.Add(search_label, 0, wx.LEFT | wx.RIGHT | wx.TOP, 10)

        row = wx.BoxSizer(wx.HORIZONTAL)
        self.search_ctrl = wx.TextCtrl(panel, style=wx.TE_PROCESS_ENTER, name="Linha de ônibus")
        self.search_ctrl.SetHint("Exemplo: T1, 54, Centro")
        self.search_button = wx.Button(panel, label="&Pesquisar")
        row.Add(self.search_ctrl, 1, wx.RIGHT | wx.EXPAND, 8)
        row.Add(self.search_button, 0)
        main.Add(row, 0, wx.ALL | wx.EXPAND, 10)

        main.Add(wx.StaticText(panel, label="Resultados:"), 0, wx.LEFT | wx.RIGHT | wx.TOP, 10)
        self.results = wx.ListCtrl(
            panel,
            style=wx.LC_REPORT | wx.LC_SINGLE_SEL,
            name="Resultados encontrados",
        )
        self.results.InsertColumn(0, "Ref", width=90)
        self.results.InsertColumn(1, "Nome", width=300)
        self.results.InsertColumn(2, "Origem", width=150)
        self.results.InsertColumn(3, "Destino", width=150)
        self.results.InsertColumn(4, "Operador", width=180)
        self.results.InsertColumn(5, "ID OSM", width=100)
        main.Add(self.results, 1, wx.ALL | wx.EXPAND, 10)

        self.download_button = wx.Button(panel, label="&Baixar selecionada")
        self.download_button.Disable()
        main.Add(self.download_button, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)

        self.status_text = wx.StaticText(panel, label="Pronto.")
        main.Add(self.status_text, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM | wx.EXPAND, 10)
        panel.SetSizer(main)

        self.CreateStatusBar()
        self.SetStatusText("Pronto.")

        self.search_button.Bind(wx.EVT_BUTTON, self.on_search)
        self.search_ctrl.Bind(wx.EVT_TEXT_ENTER, self.on_search)
        self.results.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.on_activate_result)
        self.results.Bind(wx.EVT_LIST_ITEM_SELECTED, self.on_selection_changed)
        self.download_button.Bind(wx.EVT_BUTTON, self.on_download)
        self.Bind(wx.EVT_CHAR_HOOK, self.on_char_hook)

        self.Centre()
        self.search_ctrl.SetFocus()

    def announce(self, message: str):
        self.status_text.SetLabel(message)
        self.SetStatusText(message)
        self.status_text.SetName(message)

    def set_busy(self, busy: bool, message: str | None = None):
        self.busy = busy
        self.search_ctrl.Enable(not busy)
        self.search_button.Enable(not busy)
        self.results.Enable(not busy)
        self.download_button.Enable((not busy) and self.results.GetFirstSelected() != -1)
        if message:
            self.announce(message)

    def on_char_hook(self, event):
        key = event.GetKeyCode()
        if event.ControlDown() and key in (ord("L"), ord("l")):
            self.search_ctrl.SetFocus()
            self.search_ctrl.SelectAll()
            return
        if key == wx.WXK_F5:
            self.on_search(None)
            return
        event.Skip()

    def on_search(self, event):
        if self.busy:
            return
        term = self.search_ctrl.GetValue().strip()
        if not term:
            wx.MessageBox("Digite uma referência ou nome de linha.", APP_TITLE,
                          wx.OK | wx.ICON_INFORMATION, self)
            self.search_ctrl.SetFocus()
            return

        self.results.DeleteAllItems()
        self.routes.clear()
        self.set_busy(True, f'Pesquisando por "{term}"...')
        threading.Thread(target=self._search_worker, args=(term,), daemon=True).start()

    def _search_worker(self, term: str):
        try:
            wx.CallAfter(self._search_done, search_routes(term))
        except Exception as exc:
            wx.CallAfter(self._operation_failed, "Erro na pesquisa", exc)

    def _search_done(self, routes):
        self.routes = routes
        for index, route in enumerate(routes):
            row = self.results.InsertItem(index, route.get("ref", ""))
            self.results.SetItem(row, 1, route.get("name", ""))
            self.results.SetItem(row, 2, route.get("from", ""))
            self.results.SetItem(row, 3, route.get("to", ""))
            self.results.SetItem(row, 4, route.get("operator", ""))
            self.results.SetItem(row, 5, str(route.get("id", "")))

        self.set_busy(False)
        count = len(routes)
        if not count:
            self.announce("Nenhuma linha encontrada.")
            self.search_ctrl.SetFocus()
            return

        self.announce(f"{count} linha{'s' if count != 1 else ''} encontrada{'s' if count != 1 else ''}. Use as setas e pressione Enter para baixar.")
        self.results.Select(0)
        self.results.Focus(0)
        self.results.SetFocus()

    def on_selection_changed(self, event):
        self.download_button.Enable(not self.busy)
        index = event.GetIndex()
        if 0 <= index < len(self.routes):
            self.announce(route_accessible_text(self.routes[index]))
        event.Skip()

    def on_activate_result(self, event):
        if not self.busy:
            self.download_selected(event.GetIndex())

    def on_download(self, event):
        if self.busy:
            return
        index = self.results.GetFirstSelected()
        if index == -1:
            wx.MessageBox("Selecione uma linha primeiro.", APP_TITLE,
                          wx.OK | wx.ICON_INFORMATION, self)
            return
        self.download_selected(index)

    def download_selected(self, index: int):
        if not (0 <= index < len(self.routes)):
            return
        route = self.routes[index]
        with wx.FileDialog(
            self,
            "Salvar GeoJSON",
            wildcard="GeoJSON (*.geojson)|*.geojson|JSON (*.json)|*.json",
            defaultFile=safe_filename(route),
            style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT,
        ) as dialog:
            if dialog.ShowModal() != wx.ID_OK:
                self.announce("Download cancelado.")
                return
            path = Path(dialog.GetPath())

        self.set_busy(True, f"Baixando relação {route['id']} e dados próximos da rota...")
        threading.Thread(target=self._download_worker, args=(route, path), daemon=True).start()

    def _download_worker(self, route, path: Path):
        try:
            raw = download_route_context(route["id"])
            geojson = build_geojson(raw, route["id"])
            path.write_text(json.dumps(geojson, ensure_ascii=False, indent=2), encoding="utf-8")

            road_count = sum(
                1 for f in geojson["features"]
                if f["geometry"]["type"] == "LineString"
                and not str(f["properties"].get("@id", "")).startswith("relation/")
            )
            point_count = sum(1 for f in geojson["features"] if f["geometry"]["type"] == "Point")
            wx.CallAfter(self._download_done, path, len(geojson["features"]), road_count, point_count)
        except Exception as exc:
            wx.CallAfter(self._operation_failed, "Erro ao gerar GeoJSON", exc)

    def _download_done(self, path, feature_count, road_count, point_count):
        self.set_busy(False)
        message = (
            f"GeoJSON salvo em {path}. {feature_count} features: "
            f"{road_count} ruas e {point_count} pontos."
        )
        self.announce(message)
        wx.MessageBox(message, "GeoJSON salvo", wx.OK | wx.ICON_INFORMATION, self)
        self.results.SetFocus()

    def _operation_failed(self, title, exc):
        self.set_busy(False)
        message = str(exc)
        self.announce(message)
        wx.MessageBox(message, title, wx.OK | wx.ICON_ERROR, self)
        self.search_ctrl.SetFocus()


class App(wx.App):
    def OnInit(self):
        frame = MainFrame()
        frame.Show()
        return True


if __name__ == "__main__":
    app = App(False)
    app.MainLoop()
